# pyhub_shortcut/config.py

actions = [
    {"label": "Abrir Google", "command": "start https://www.google.com"},
    {"label": "Abrir Notepad", "command": "notepad"},
    {"label": "Abrir VS Code", "command": "code ."}
]
